package com.order;

import java.sql.*;
import java.util.Scanner;

public class OrderManagementSystem {

    private static final String URL = "jdbc:mysql://localhost:3306/ecommerce_db";
    private static final String USER = "root";
    private static final String PASS = "Krishna@05"; // Change this

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== ORDER MANAGEMENT SYSTEM =====");
            System.out.println("1. Insert Order Records");
            System.out.println("2. Display Orders by Status (Quantity > 2, Sorted by Price DESC)");
            System.out.println("3. Increase Order Quantity");
            System.out.println("4. Update Order Status");
            System.out.println("5. Show Total Order Value & Delete Cancelled Order");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            try (Connection con = getConnection()) {
                switch (choice) {
                    case 1 -> insertOrders(con, sc);
                    case 2 -> displayOrdersByStatus(con, sc);
                    case 3 -> increaseQuantity(con, sc);
                    case 4 -> updateOrderStatus(con, sc);
                    case 5 -> totalValueAndDeleteCancelled(con, sc);
                    case 6 -> {
                        System.out.println("Exiting...");
                        sc.close();
                        return;
                    }
                    default -> System.out.println("Invalid choice! Try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database Error: " + e.getMessage());
            }
        }
    }

    // (a) Insert at least three order records using PreparedStatement & handle duplicate IDs
    private static void insertOrders(Connection con, Scanner sc) throws SQLException {
        System.out.print("How many orders do you want to insert? (enter at least 3): ");
        int count = sc.nextInt();
        sc.nextLine();

        String sql = "INSERT INTO Orders (order_id, customer_name, product_name, quantity, unit_price, status) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 1; i <= count; i++) {
                System.out.println("\n--- Enter details for Order " + i + " ---");
                System.out.print("Order ID: ");
                int id = sc.nextInt();
                sc.nextLine();

                System.out.print("Customer Name: ");
                String customer = sc.nextLine();

                System.out.print("Product Name: ");
                String product = sc.nextLine();

                System.out.print("Quantity: ");
                int qty = sc.nextInt();

                System.out.print("Unit Price: ");
                double price = sc.nextDouble();
                sc.nextLine();

                System.out.print("Status (Pending / Shipped / Delivered / Cancelled): ");
                String status = sc.nextLine();

                ps.setInt(1, id);
                ps.setString(2, customer);
                ps.setString(3, product);
                ps.setInt(4, qty);
                ps.setDouble(5, price);
                ps.setString(6, status);

                try {
                    ps.executeUpdate();
                    System.out.println("Order " + id + " inserted successfully!");
                } catch (SQLIntegrityConstraintViolationException e) {
                    System.out.println("Error: Duplicate Order ID (" + id + ")! Skipping this record.");
                }
            }
        }
    }

    // (b) Display orders by status with quantity > 2, sorted by unit_price DESC
    private static void displayOrdersByStatus(Connection con, Scanner sc) throws SQLException {
        System.out.print("Enter order status to search: ");
        String status = sc.nextLine();

        String sql = "SELECT * FROM Orders WHERE LOWER(status) = LOWER(?) AND quantity > 2 ORDER BY unit_price DESC";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                boolean found = false;
                System.out.println("\nID | Customer | Product | Qty | Unit Price | Status");
                System.out.println("---------------------------------------------------------");
                while (rs.next()) {
                    found = true;
                    printOrderRow(rs);
                }
                if (!found) {
                    System.out.println("No orders found with status '" + status + "' and quantity > 2.");
                }
            }
        }
    }

    // (c) Increase existing quantity of an order by a given amount
    private static void increaseQuantity(Connection con, Scanner sc) throws SQLException {
        System.out.print("Enter Order ID: ");
        int id = sc.nextInt();
        System.out.print("Enter additional quantity to add: ");
        int addQty = sc.nextInt();

        String sql = "UPDATE Orders SET quantity = quantity + ? WHERE order_id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, addQty);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                System.out.println("Quantity updated successfully for Order ID " + id + ".");
            } else {
                System.out.println("Order ID " + id + " does not exist.");
            }
        }
    }

    // (d) Update status only if order exists and status is Pending, Shipped, or Delivered
    private static void updateOrderStatus(Connection con, Scanner sc) throws SQLException {
        System.out.print("Enter Order ID: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter new status (Pending / Shipped / Delivered): ");
        String newStatus = sc.nextLine().trim();

        if (!newStatus.equalsIgnoreCase("Pending") &&
            !newStatus.equalsIgnoreCase("Shipped") &&
            !newStatus.equalsIgnoreCase("Delivered")) {
            System.out.println("Invalid status! Only Pending, Shipped, or Delivered are allowed.");
            return;
        }

        String checkSql = "SELECT * FROM Orders WHERE order_id = ?";
        try (PreparedStatement psCheck = con.prepareStatement(checkSql)) {
            psCheck.setInt(1, id);
            try (ResultSet rs = psCheck.executeQuery()) {
                if (!rs.next()) {
                    System.out.println("Order ID " + id + " does not exist.");
                    return;
                }
            }
        }

        String updateSql = "UPDATE Orders SET status = ? WHERE order_id = ?";
        try (PreparedStatement psUpdate = con.prepareStatement(updateSql)) {
            psUpdate.setString(1, newStatus);
            psUpdate.setInt(2, id);
            psUpdate.executeUpdate();
            System.out.println("Status updated! Updated Order Details:");
        }

        // Display updated order details
        try (PreparedStatement psShow = con.prepareStatement(checkSql)) {
            psShow.setInt(1, id);
            try (ResultSet rs = psShow.executeQuery()) {
                if (rs.next()) {
                    System.out.println("ID | Customer | Product | Qty | Unit Price | Status");
                    printOrderRow(rs);
                }
            }
        }
    }

    // (e) Display SUM(quantity * unit_price) and delete an order only if status is Cancelled
    private static void totalValueAndDeleteCancelled(Connection con, Scanner sc) throws SQLException {
        String sumSql = "SELECT SUM(quantity * unit_price) AS total_value FROM Orders";
        try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sumSql)) {
            if (rs.next()) {
                System.out.printf("Total Order Value across all orders: %.2f%n", rs.getDouble("total_value"));
            }
        }

        System.out.print("Enter Order ID to delete (only Cancelled orders can be deleted): ");
        int id = sc.nextInt();

        String checkSql = "SELECT status FROM Orders WHERE order_id = ?";
        try (PreparedStatement psCheck = con.prepareStatement(checkSql)) {
            psCheck.setInt(1, id);
            try (ResultSet rs = psCheck.executeQuery()) {
                if (!rs.next()) {
                    System.out.println("Cannot delete: Order ID " + id + " does not exist.");
                    return;
                }
                String currentStatus = rs.getString("status");
                if (!"Cancelled".equalsIgnoreCase(currentStatus)) {
                    System.out.println("Cannot delete: Order ID " + id + " has status '" + currentStatus + "' (must be Cancelled).");
                    return;
                }
            }
        }

        String deleteSql = "DELETE FROM Orders WHERE order_id = ?";
        try (PreparedStatement psDel = con.prepareStatement(deleteSql)) {
            psDel.setInt(1, id);
            psDel.executeUpdate();
            System.out.println("Cancelled Order ID " + id + " deleted successfully.");
        }
    }

    private static void printOrderRow(ResultSet rs) throws SQLException {
        System.out.printf("%d | %s | %s | %d | %.2f | %s%n",
                rs.getInt("order_id"),
                rs.getString("customer_name"),
                rs.getString("product_name"),
                rs.getInt("quantity"),
                rs.getDouble("unit_price"),
                rs.getString("status"));
    }
}