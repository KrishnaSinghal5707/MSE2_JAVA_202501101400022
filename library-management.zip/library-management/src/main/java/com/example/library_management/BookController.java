package com.example.library_management;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    private List<Book> bookList = new ArrayList<>();

    // (b) Add a new book
    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        bookList.add(book);
        return new ResponseEntity<>(book, HttpStatus.CREATED); // 201 Created
    }

    // (c) Retrieve all books
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(bookList); // 200 OK
    }

    // (c) Retrieve a specific book by ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookById(@PathVariable("id") Integer id) {
        for (Book b : bookList) {
            if (b.getId().equals(id)) {
                return ResponseEntity.ok(b); // 200 OK
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Book not found with ID: " + id); // 404 Not Found
    }

    // (d) Update a book's details
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBook(@PathVariable("id") Integer id, @RequestBody Book updatedBook) {
        for (Book b : bookList) {
            if (b.getId().equals(id)) {
                b.setTitle(updatedBook.getTitle());
                b.setAuthor(updatedBook.getAuthor());
                b.setCategory(updatedBook.getCategory());
                b.setAvailableCopies(updatedBook.getAvailableCopies());
                return ResponseEntity.ok(b); // 200 OK
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Book not found with ID: " + id); // 404 Not Found
    }

    // (e) Delete a book by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable("id") Integer id) {
        boolean removed = bookList.removeIf(b -> b.getId().equals(id));
        if (removed) {
            return ResponseEntity.ok("Book deleted successfully with ID: " + id); // 200 OK
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("Book not found with ID: " + id); // 404 Not Found
    }
}